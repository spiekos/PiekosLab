DP3 base-model performance metrics
VERSION B — CORRECTED (train/test split applied before ComBat, no outcome labels)
Generated 2026-08-12

>>> These are the defensible numbers.
>>> A companion package, VERSION A (UNCORRECTED), contains the same models run
>>> on the preprocessing as originally received.


CONTENTS
========
  5timepoints_all.csv            48 rows — all models, all datasets
  5timepoints_metabolomics.csv
  5timepoints_lipidomics.csv
  ECHO2windows_all.csv           16 rows
  ECHO2windows_metabolomics.csv
  ECHO2windows_lipidomics.csv

Coverage: plasma metabolomics and plasma lipidomics across the 5 defined
timepoints (T1 6-14, T2 14-22, T3 22-32, T4 32-37, T5 37-42 wks) and the 2
ECHO-aligned windows (W1 6-20, W2 >=28 wks), plus placenta metabolomics and
placenta lipidomics unwindowed. Four models throughout. Identical coverage to
Version A, so the two are directly comparable row for row.


WHAT CHANGED VERSUS VERSION A
=============================
Re-processed from the raw Compound Discoverer exports with two changes:

1. THE SPLIT COMES FIRST.
   The 70/30 participant-level split is applied before any preprocessing.
   ComBat, ISTD and median-fold-change normalization, the missingness / RSD /
   IQR filters and imputation are all fitted on the 268 development
   participants only. The 116 test participants influence nothing.

2. NO OUTCOME LABELS IN THE COMBAT DESIGN.
   'Subgroup' and 'GestAgeDelivery' removed. 'SampleGestAge' retained: when a
   sample was drawn is known at collection time and is not an outcome.

Nothing about the modelling changed. Both versions use the same
participant-level 70/30 locked split, nested cross-validation (5 outer x 3
inner, grouped by participant), Optuna TPE with 40 trials per fold, PR-AUC for
model selection, and bootstrap confidence intervals over pooled out-of-fold
predictions. The same four models throughout: elastic-net logistic regression,
random forest, XGBoost, SVM.

The 116-participant held-out test set has not been opened.


HEADLINE RESULT
===============
Mean out-of-fold PR-AUC, Version A -> Version B:

                                     5 timepoints      2 ECHO windows
  LogisticRegression (elastic-net)   0.633 -> 0.570    0.679 -> 0.562
  RandomForest                       0.908 -> 0.504    0.980 -> 0.503
  XGBoost                            0.892 -> 0.505    0.971 -> 0.458
  SVM                                0.659 -> 0.441    0.680 -> 0.530

The tree models fall furthest because they recombined the leaked signal most
aggressively. Elastic net moves least, because its shrinkage was already
discarding most of it.


HOW TO READ THESE NUMBERS
=========================
Compare every PR-AUC against the 'prevalence' column, which is what a model
scores by chance at that class balance. In this version, only 1 of 60
model configurations has a 95% CI lower bound above its own prevalence
baseline; the rest are statistically indistinguishable from chance.

At 30-89 development participants per window against 570-2500 features, that is
the expected result. It is not evidence that the biology is absent — it is
evidence that this sample size cannot yet demonstrate it. Reporting these
alongside the correction is defensible; reporting Version A is not.

Note T4 (32-37 wks) has only 30 development participants and its intervals span
roughly 0.2 units; treat that window as underpowered.


COLUMN GUIDE
============
  pr_auc_oof            PR-AUC on pooled out-of-fold predictions (primary)
  pr_lo / pr_hi         95% CI, percentile bootstrap (1000x)
  prevalence            PR-AUC expected by chance — compare against it
  roc_auc, accuracy, f1, precision, recall_sens, specificity, brier
  feats_in              features entering the model
  feats_sel             mean features surviving elastic-net selection per fold
