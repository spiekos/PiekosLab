# DP3 Metabolomics – Project File Reference

**Pipeline:** SOP v2 (HMDB) · ComBat batch correction · Differential analysis → binary classifier  
**Datasets:** MTBL_plasma, MTBL_placenta

---

## Primary Code Files (`03_model_development/`)

| File | Purpose |
|------|---------|
| `utilities.py` | Shared helpers: data loading, label normalisation, significant-analyte loading |
| `binary_classifier.py` | Core pipeline — differential pre-filter, Optuna hyperparameter tuning, model fitting and evaluation |
| `run_sop_models.py` | Run binary classifier with differential pre-filter (main analysis); saves to `04_results_and_figures/models/binary/MTBL_sop/` |
| `run_sop_nodiff.py` | Run binary classifier without differential pre-filter (sensitivity check); saves to `…/MTBL_sop_nodiff/` |
| `superset_differential_analysis.py` | Post-hoc differential analysis across LASSO-selected features |
| `feature_interpretation.py` | Post-hoc: feature importance plots, SHAP, coefficient heatmaps |

---

## Input Data (`data/cleaned/sop_omics_pipeline_v2/`)

Each tissue subfolder (`MTBL_plasma`, `MTBL_placenta`) contains:

| File | Contents |
|------|---------|
| `{tissue}_cleaned_with_metadata.csv` | Full cleaned feature matrix with all sample metadata |
| `{tissue}_suffix_{A-E}.csv` | Per-timepoint slices (plasma only; A–E = timepoints 1–5) |
| `{tissue}_dedup_log.csv` | Every feature dropped during deduplication with phase and reason |
| `{tissue}_feature_filters.csv` | Features removed by the QC RSD filter with per-feature RSD values |
| `{tissue}_feature_metadata.csv` | Annotation tier, compound name, m/z, RT for all retained features |
| `{tissue}_sample_filters.csv` | Samples removed and reason |
| `pipeline_log.txt` | Full preprocessing summary: filter counts, annotation tiers, batch correction notes, QC warnings |
| `diagnostics/` | PCA plots (pre/post correction, batch and group colouring), normalisation curves |

---

## Differential Analysis Outputs (`04_results_and_figures/differential_analysis/MTBL_sop/`)

```
plasma/
    cross_sectional/{A,B,C,D,E}/
        Control_vs_Complication_differential_results.csv   ← one row per analyte; columns: feature, log2FC, p_value, q_value
    longitudinal/
        {Group}_{T2}_minus_{T1}_longitudinal_results.csv   ← adjacent-timepoint delta comparisons per group
placenta/
    cross_sectional/
        Control_vs_Complication_differential_results.csv
```

**Working subset (409 features):** union of all cross-sectional comparisons across timepoints and all longitudinal delta comparisons across groups, q < 0.05. Any feature significant in at least one test is retained. This is the intended feature set for downstream analyses.

Cross-sectional significant analytes by timepoint (plasma, q < 0.05):

| Timepoint | Sig. analytes / 502 |
|-----------|---------------------|
| A | 40 |
| B | 72 |
| C | 68 |
| D | 49 |
| E | 43 |

---

## Model Outputs (`04_results_and_figures/models/binary/`)

### `MTBL_sop/` — main analysis

ML pre-filter uses cross-sectional results at the timepoint of interest only (q < 0.05). The broader 409-feature working subset is maintained separately for downstream analyses.

```
plasma/{A,B,C,D,E}/
    summary.json                ← n_features pre-filter, best model, test metrics
    lasso_selected_features.csv ← features entering the model with coefficients
    test_results.csv            ← per-sample predictions and true labels
    tuned_hyperparams.json      ← best hyperparameters from Optuna
placenta/all/
    (same structure)
all_summaries.json              ← consolidated summary across all timepoints
```

### `MTBL_sop_nodiff/` — sensitivity run (no differential pre-filter)

Same structure. All 502 features passed to the classifier. Use for comparison only.

---

## Gallery and Reports

| File | Purpose |
|------|---------|
| `MTBL_QC_modelling_summary_v2.pptx` | Slide deck: POS/NEG PCA before/after correction, full feature pipeline table, deduplication breakdown |
| `documentation.md` | This file |

---

## Key Numbers (MTBL Plasma)

| Stage | Features | Note |
|-------|----------|------|
| Raw (POS + NEG merged) | 9,744 | Pre-processing starting point |
| Feature missingness filter | 9,744 | Exclude features >20% missing in control or complication group — no features failed |
| Sample missingness filter | 9,744 | Exclude samples >50% missing — 7 samples removed, feature count unchanged |
| QC-pool RSD filter | 1,074 | Exclude features with QC RSD >30% in any batch, applied post-ComBat |
| IQR filter | 1,074 | Exclude near-constant and hypervariable features within timepoint — no features failed |
| Deduplication | 502 | 572 dropped: adduct/isotope/fragment collapse (500), named within-compound (49), m/z + RT (22), formula + RT (1) |
| Differential filter | 409 | Working subset: cross-sectional all TPs + all longitudinal deltas, q < 0.05 |
