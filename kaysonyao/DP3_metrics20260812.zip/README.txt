DP3 base-model performance metrics
VERSION A — UNCORRECTED (ComBat fitted on all data, with outcome labels)
Generated 2026-08-12

>>> These numbers are affected by information leakage. See "Why" below.
>>> A companion package, VERSION B (CORRECTED), contains the same models run
>>> on the same participants with the leakage removed.


CONTENTS
========
  5timepoints_all.csv            48 rows — all models, all datasets
  5timepoints_metabolomics.csv
  5timepoints_lipidomics.csv
  ECHO2windows_all.csv           16 rows
  ECHO2windows_metabolomics.csv
  ECHO2windows_lipidomics.csv

Coverage: plasma metabolomics and plasma lipidomics across the 5 defined
timepoints (T1 6-14, T2 14-22, T3 22-32, T4 32-37, T5 37-42 wks) and the 2
ECHO-aligned windows (W1 6-20, W2 >=28 wks), plus placenta metabolomics and
placenta lipidomics unwindowed. Four models throughout.


WHAT THIS VERSION IS
====================
Preprocessing exactly as received (2026-08-12 pipeline run). ComBat batch
correction was fitted on all 530 samples at once, with the design matrix:

    protected = ['Subgroup', 'SampleGestAge', 'GestAgeDelivery']


WHY THE NUMBERS ARE INFLATED
============================
Two issues, both in preprocessing rather than modelling:

1. OUTCOME LABELS IN THE BATCH-CORRECTION DESIGN.
   'Subgroup' is the diagnosis. 'GestAgeDelivery' is what defines preterm
   birth. Including them means every feature value was adjusted using
   knowledge of each participant's outcome, so the outcome ends up partly
   encoded in the predictors the model then reads.

   This is standard, correct ComBat practice when the goal is DESCRIBING
   differences between groups — it stops batch correction from flattening real
   biology. It is not appropriate when the same matrix is used to PREDICT
   those groups.

2. THE HELD-OUT TEST SET INFLUENCED THE CORRECTION.
   ComBat was fitted across all participants, so the 116 locked test
   participants shaped the values every model was trained on.

Symptom: RandomForest and XGBoost reach ROC-AUC 1.000 in several windows on
fewer than 90 participants. Elastic-net logistic regression, whose shrinkage
discards most of the leaked signal, sits 0.3-0.5 lower on the same data. That
gap between linear and tree models is the fingerprint of label information in
the features rather than a biological result.


WHAT IS STILL VALID HERE
========================
The modelling itself is sound and identical to Version B: participant-level
70/30 locked split, nested cross-validation (5 outer x 3 inner, grouped by
participant), Optuna TPE with 40 trials per fold, models selected on PR-AUC,
bootstrap confidence intervals over pooled out-of-fold predictions. Only the
268 development participants were used; the 116-participant test set was never
opened.

The underlying cleaned matrices remain appropriate for differential analysis
and figures, where preserving group differences is the intent.


COLUMN GUIDE
============
  pr_auc_oof            PR-AUC on pooled out-of-fold predictions (primary)
  pr_lo / pr_hi         95% CI, percentile bootstrap (1000x)
  prevalence            PR-AUC expected by chance — compare against it
  roc_auc, accuracy, f1, precision, recall_sens, specificity, brier
  feats_in              features entering the model
  feats_sel             mean features surviving elastic-net selection per fold
